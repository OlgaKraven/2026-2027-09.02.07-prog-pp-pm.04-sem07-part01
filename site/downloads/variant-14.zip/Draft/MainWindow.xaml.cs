using System.Globalization;
using System.IO;
using System.Text;
using System.Windows;
using Microsoft.Win32;

namespace ServiceDeskWpf;

internal record Ticket(int Id, string Item, string Owner, DateTime Due, string Status);

internal static class TestData
{
    public static List<Ticket> Create(DateTime today) =>
    [
        new Ticket(101, "Растение А", "Агроном А", today.AddDays(-2), "Открыта"),
        new Ticket(102, "Растение Б", "Агроном Б", today.AddDays(-1), "Завершена")
    ];

    public static int CountOverdue(IEnumerable<Ticket> tickets, DateTime today) =>
        tickets.Count(t => t.Status != "Завершена" && t.Due.Date < today.Date);
}

internal static class CsvStore
{
    public static List<Ticket> Read(string path)
    {
        var rows = new List<Ticket>();
        foreach (var line in File.ReadAllLines(path, Encoding.UTF8).Skip(1))
        {
            if (string.IsNullOrWhiteSpace(line)) continue;
            var cells = line.Split(';');
            rows.Add(new Ticket(int.Parse(cells[0]), cells[1], cells[2],
                DateTime.ParseExact(cells[3], "dd.MM.yyyy", CultureInfo.InvariantCulture), cells[4]));
        }
        return rows;
    }

    public static void Write(string path, IEnumerable<Ticket> rows)
    {
        var lines = new List<string> { "Id,Item,Owner,Due,Status" };
        lines.AddRange(rows.Select(t => $"{t.Id},{t.Item},{t.Owner},{t.Due:yyyy-MM-dd},{t.Status}"));
        File.WriteAllLines(path, lines, Encoding.UTF8);
    }

    public static int CountOverdue(IEnumerable<Ticket> rows, DateTime today) =>
        rows.Count(t => t.Due.Date < today.Date);
}

public partial class MainWindow : Window
{
    private List<Ticket> tickets = new();
    private DateTime CheckDate => ControlDate.SelectedDate!.Value.Date;

    public MainWindow(string? demoPath = null, DateTime? checkDate = null)
    {
        InitializeComponent();
        ControlDate.SelectedDate = checkDate ?? new DateTime(2026, 10, 1);
        if (demoPath != null) Loaded += (_, _) =>
            Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.ApplicationIdle,
                new Action(() => LoadCsv(demoPath)));
    }

    private void ControlDate_Changed(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
    {
        if (ControlDate.SelectedDate is null)
            ControlDate.SelectedDate = new DateTime(2026, 10, 1);
    }

    private void LoadTestData_Click(object sender, RoutedEventArgs e) => LoadTestData();

    private void LoadTestData()
    {
        tickets = TestData.Create(CheckDate);
        TicketsGrid.ItemsSource = tickets.ToList();
        StatusText.Text = $"Тестовых записей: {tickets.Count}";
    }

    private void OpenCsv_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog { Filter = "CSV (*.csv)|*.csv" };
        if (dialog.ShowDialog() == true) LoadCsv(dialog.FileName);
    }

    private void LoadCsv(string path)
    {
        try
        {
            tickets = CsvStore.Read(path);
            TicketsGrid.ItemsSource = tickets.ToList();
            StatusText.Text = $"Загружено: {tickets.Count}";
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Ошибка импорта"); }
    }

    private void SaveCsv_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new SaveFileDialog { Filter = "CSV (*.csv)|*.csv", FileName = "export.csv" };
        if (dialog.ShowDialog() != true) return;
        try { CsvStore.Write(dialog.FileName, tickets); StatusText.Text = "Файл сохранён"; }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Ошибка экспорта"); }
    }

    private void CountOverdue_Click(object sender, RoutedEventArgs e) =>
        StatusText.Text = $"Просрочено: {CsvStore.CountOverdue(tickets, CheckDate)}";
}
